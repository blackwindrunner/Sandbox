//>>built
define("dojox/mobile/nls/sv/messages",{"CarouselPrevious":"Föregående","CarouselNext":"Nästa","PageIndicatorLabel":"sida $0 av $1"});