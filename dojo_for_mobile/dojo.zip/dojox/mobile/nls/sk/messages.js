//>>built
define("dojox/mobile/nls/sk/messages",{"CarouselPrevious":"Predchádzajúci","CarouselNext":"Nasledujúci","PageIndicatorLabel":"stránka $0 z $1"});