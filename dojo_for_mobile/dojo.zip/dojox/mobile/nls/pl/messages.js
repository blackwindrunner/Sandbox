//>>built
define("dojox/mobile/nls/pl/messages",{"CarouselPrevious":"Wstecz","CarouselNext":"Dalej","PageIndicatorLabel":"Strona $0 z $1"});