//>>built
define("dojox/mobile/nls/da/messages",{"CarouselPrevious":"Forrige","CarouselNext":"Næste","PageIndicatorLabel":"side $0 af $1"});