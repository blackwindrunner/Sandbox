//>>built
define("dojox/mobile/nls/cs/messages",{"CarouselPrevious":"Předchozí","CarouselNext":"Další","PageIndicatorLabel":"stránka $0 ze $1"});