//>>built
define("dojox/mobile/nls/pt/messages",{"CarouselPrevious":"Anterior","CarouselNext":"Próximo","PageIndicatorLabel":"página $0 de $1"});