//>>built
define("dojox/mobile/nls/hr/messages",{"CarouselPrevious":"Prethodno","CarouselNext":"Sljedeće","PageIndicatorLabel":"stranica $0 od $1"});