//>>built
define("dojox/mobile/nls/ca/messages",{"CarouselPrevious":"Anterior","CarouselNext":"Següent","PageIndicatorLabel":"pàgina $0 de $1"});