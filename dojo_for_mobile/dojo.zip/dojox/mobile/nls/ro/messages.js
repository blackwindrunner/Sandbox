//>>built
define("dojox/mobile/nls/ro/messages",{"CarouselPrevious":"Anterioară","CarouselNext":"Următoare","PageIndicatorLabel":"pagina $0 din $1"});