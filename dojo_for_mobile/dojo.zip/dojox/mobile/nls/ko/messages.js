//>>built
define("dojox/mobile/nls/ko/messages",{"CarouselPrevious":"이전","CarouselNext":"다음","PageIndicatorLabel":"페이지 $0/$1"});