//>>built
define("dojox/mobile/nls/nl/messages",{"CarouselPrevious":"Vorige","CarouselNext":"Volgende","PageIndicatorLabel":"pagina $0 van $1"});