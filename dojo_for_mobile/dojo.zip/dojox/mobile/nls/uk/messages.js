//>>built
define("dojox/mobile/nls/uk/messages",{"CarouselPrevious":"Назад","CarouselNext":"Далі","PageIndicatorLabel":"стор. $0 з $1"});