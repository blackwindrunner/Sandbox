//>>built
define("dojox/mobile/nls/kk/messages",{"CarouselPrevious":"Алдыңғы","CarouselNext":"Келесі","PageIndicatorLabel":"$1 беттің $0-беті"});