//>>built
define("dojox/mobile/nls/it/messages",{"CarouselPrevious":"Precedente","CarouselNext":"Avanti","PageIndicatorLabel":"pagina $0 di $1"});