//>>built
define("dojox/mobile/nls/fr/messages",{"CarouselPrevious":"Précédent","CarouselNext":"Suivant","PageIndicatorLabel":"page $0 sur $1"});