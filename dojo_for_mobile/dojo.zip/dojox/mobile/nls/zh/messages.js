//>>built
define("dojox/mobile/nls/zh/messages",{"CarouselPrevious":"上一步","CarouselNext":"下一步","PageIndicatorLabel":"第 $0 页（共 $1 页）"});