//>>built
define("dojox/mobile/nls/fi/messages",{"CarouselPrevious":"Edellinen","CarouselNext":"Seuraava","PageIndicatorLabel":"sivu $0 / $1"});