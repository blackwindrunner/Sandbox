//>>built
define("dojox/mobile/nls/he/messages",{"CarouselPrevious":"הקודם","CarouselNext":"הבא","PageIndicatorLabel":"דף $0 מתוך $1"});