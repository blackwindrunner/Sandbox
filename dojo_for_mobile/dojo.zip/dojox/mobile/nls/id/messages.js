//>>built
define("dojox/mobile/nls/id/messages",{"CarouselPrevious":"Sebelumnya","CarouselNext":"Berikutnya","PageIndicatorLabel":"halaman $0 dari $1"});