//>>built
define("dojox/mobile/nls/sl/messages",{"CarouselPrevious":"Prejšnji","CarouselNext":"Naprej","PageIndicatorLabel":"Stran $0 od $1"});