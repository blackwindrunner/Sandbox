//>>built
define("dojox/mobile/nls/ru/messages",{"CarouselPrevious":"Назад","CarouselNext":"Далее","PageIndicatorLabel":"стр. $0 из $1"});