//>>built
define("dojox/mobile/nls/tr/messages",{"CarouselPrevious":"Geri","CarouselNext":"İleri","PageIndicatorLabel":"sayfa $0 / $1"});