//>>built
define("dojox/mobile/nls/bg/messages",{"CarouselPrevious":"Предишен","CarouselNext":"Следващ","PageIndicatorLabel":"Страница $0 от $1"});