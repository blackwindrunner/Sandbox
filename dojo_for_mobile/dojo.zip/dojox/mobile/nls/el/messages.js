//>>built
define("dojox/mobile/nls/el/messages",{"CarouselPrevious":"Προηγούμενο","CarouselNext":"Επόμενο","PageIndicatorLabel":"σελίδα $0 από $1"});