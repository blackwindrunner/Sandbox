//>>built
define("dojox/mobile/nls/pt-pt/messages",{"CarouselPrevious":"Anterior","CarouselNext":"Seguinte","PageIndicatorLabel":"página $0 de $1"});