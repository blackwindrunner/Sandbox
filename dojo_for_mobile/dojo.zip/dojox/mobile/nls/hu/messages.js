//>>built
define("dojox/mobile/nls/hu/messages",{"CarouselPrevious":"Előző","CarouselNext":"Következő","PageIndicatorLabel":"$0 / $1 oldal"});