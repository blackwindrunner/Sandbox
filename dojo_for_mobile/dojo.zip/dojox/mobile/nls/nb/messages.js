//>>built
define("dojox/mobile/nls/nb/messages",{"CarouselPrevious":"Forrige","CarouselNext":"Neste","PageIndicatorLabel":"side $0 av $1"});