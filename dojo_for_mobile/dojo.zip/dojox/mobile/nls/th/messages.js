//>>built
define("dojox/mobile/nls/th/messages",{"CarouselPrevious":"ก่อนหน้านี้","CarouselNext":"ถัดไป","PageIndicatorLabel":"หน้า $0 จาก $1"});