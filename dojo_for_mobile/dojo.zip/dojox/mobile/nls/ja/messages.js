//>>built
define("dojox/mobile/nls/ja/messages",{"CarouselPrevious":"前へ","CarouselNext":"次へ","PageIndicatorLabel":"$1 ページ中の $0"});