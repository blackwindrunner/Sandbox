//>>built
define("dojox/mobile/nls/de/messages",{"CarouselPrevious":"Zurück","CarouselNext":"Weiter","PageIndicatorLabel":"Seite $0 von $1"});