//>>built
define("dojox/mobile/nls/ar/messages",{"CarouselPrevious":"سابق","CarouselNext":"تالي","PageIndicatorLabel":"الصفحة $0 من $1"});