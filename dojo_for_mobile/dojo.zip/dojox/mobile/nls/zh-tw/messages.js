//>>built
define("dojox/mobile/nls/zh-tw/messages",{"CarouselPrevious":"上一步","CarouselNext":"下一步","PageIndicatorLabel":"第 $1 之 $0 頁"});