//>>built
define("dojo/cldr/nls/ak/number",{"currencyFormat":"¤#,##0.00","group":",","decimal":"."});