//>>built
define("dojo/cldr/nls/ar-sa/number",{"currencyFormat":"¤#0.00"});