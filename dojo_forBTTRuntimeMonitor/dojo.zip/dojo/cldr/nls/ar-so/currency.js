//>>built
define("dojo/cldr/nls/ar-so/currency",{"SOS_symbol":"S"});