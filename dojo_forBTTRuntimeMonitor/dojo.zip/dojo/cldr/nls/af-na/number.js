//>>built
define("dojo/cldr/nls/af-na/number",{"currencyFormat":"¤ #,##0.00"});