//>>built
define("dojo/cldr/nls/ar-qa/number",{"currencyFormat":"¤#0.00"});