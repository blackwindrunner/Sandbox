//>>built
define("dojo/cldr/nls/ar-lb/currency",{"SDG_symbol":"SDG"});