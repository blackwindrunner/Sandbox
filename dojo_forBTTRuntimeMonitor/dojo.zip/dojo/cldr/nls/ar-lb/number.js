//>>built
define("dojo/cldr/nls/ar-lb/number",{"group":".","decimal":","});