//>>built
define("dojo/cldr/nls/ar-ma/number",{"group":".","decimal":","});