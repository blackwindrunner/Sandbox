//>>built
define("dojo/cldr/nls/agq/number",{"decimalFormat":"#,##0.###","group":" ","percentFormat":"#,##0%","currencyFormat":"#,##0.00¤","decimal":","});