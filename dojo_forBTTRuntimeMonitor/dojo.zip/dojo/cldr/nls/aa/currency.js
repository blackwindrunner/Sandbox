//>>built
define("dojo/cldr/nls/aa/currency",{"ETB_symbol":"Br"});