################################################################
#                                                              #
# File: dropAgentAdminTables.sh                                #
#                                                              #
# Usage: dropAgentAdminTables.sh userid password               #
#                                                              #
# This script drops all tables for the                         #
# Agent Admin e-Component on AIX platform.                     #
#                                                              #
################################################################

if [ $# -ne 2 ]
then
   echo "Usage: dropAgentAdminTables.sh userid password"
   exit 1
fi

#
# Drop tables.
#

echo "Dropping tables for Agent Admin"
db2 "CONNECT TO BTF user $1 using $2"
db2 "DROP TABLE BTF.USERS"
db2 "COMMIT WORK"
db2 "DROP TABLE BTF.CONTEXTS"
db2 "COMMIT WORK"
db2 "DROP TABLE BTF.RIGHTS"
db2 "COMMIT WORK"
db2 "DROP TABLE BTF.ROLES"
db2 "COMMIT WORK"
db2 "DROP TABLE BTF.SERVICES"
db2 "COMMIT WORK"
db2 "DROP TABLE BTF.GROUPS"
db2 "COMMIT WORK"
db2 "DROP TABLE BTF.CONFIGURATION"
db2 "COMMIT WORK"
db2 "CONNECT RESET"
db2 "DISCONNECT ALL"
db2 "TERMINATE"
