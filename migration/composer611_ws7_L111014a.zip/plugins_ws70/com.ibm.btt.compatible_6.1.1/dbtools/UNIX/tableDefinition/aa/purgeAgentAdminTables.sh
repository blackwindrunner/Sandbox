################################################################
#                                                              #
# File: purgeAgentAdminTables.sh                               #
#                                                              #
# Usage: purgeAgentAdminTables.sh userid password              #
#                                                              #
# This script purges all tables for the                        #
# Agent Admin e-Component on UNIX platforms.                   #
#                                                              #
################################################################

if [ $# -ne 2 ]
then
	echo "Usage: purgeAgentAdminTables.sh userid password"
	exit 1
fi

#
# Purge tables.
#

echo "Purging tables for Agent Admin."
db2 "CONNECT TO BTF user $1 using $2"
db2 "DELETE FROM BTF.USERS"
db2 "COMMIT"
db2 "DELETE FROM BTF.RIGHTS"
db2 "COMMIT"
db2 "DELETE FROM BTF.ROLES"
db2 "COMMIT"
db2 "DELETE FROM BTF.SERVICES"
db2 "COMMIT"
db2 "DELETE FROM BTF.GROUPS"
db2 "COMMIT"
db2 "DELETE FROM BTF.CONTEXTS"
db2 "COMMIT"
db2 "DELETE FROM BTF.CONFIGURATION"
db2 "COMMIT"
db2 "CONNECT RESET"
db2 "DISCONNECT ALL"
db2 "TERMINATE"
