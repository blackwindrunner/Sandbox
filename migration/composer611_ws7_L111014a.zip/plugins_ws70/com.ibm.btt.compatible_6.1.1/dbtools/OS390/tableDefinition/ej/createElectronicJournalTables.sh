java com.ibm.dse.samples.ej.server.CreateEJTable createElectronicJournalTables.txt
