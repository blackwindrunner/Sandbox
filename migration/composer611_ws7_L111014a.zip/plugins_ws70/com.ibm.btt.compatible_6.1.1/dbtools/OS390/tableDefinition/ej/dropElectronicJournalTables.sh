java com.ibm.dse.samples.ej.server.RemoveEJTable createElectronicJournalTables.txt
