################################################################
#                                                              #
# File: createElectronicJournalTables.sh                       #
#                                                              #
# This script creates the electronic journal                   #
# tables on the iSeries platform.                              #
#  							       #
# Note:  Ensure the following jars are in the classpath:       #
#	 dseb.jar					       # 
#	 dsejdbjsvc.jar					       #
#	 dseevsvr.jar					       #
#	 dsesci.jar					       #
#	 db2_classes.jar(native) or jt400.jar(toolkit)	       #
#                                                              #
################################################################


java com.ibm.dse.samples.ej.server.CreateEJTable createElectronicJournalTables.txt
