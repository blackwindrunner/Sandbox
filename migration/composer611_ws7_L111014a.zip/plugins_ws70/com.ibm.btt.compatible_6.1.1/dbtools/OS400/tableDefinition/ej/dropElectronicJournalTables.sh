################################################################
#                                                              #
# File: dropElectronicJournalTables.sh                         #
#                                                              #
# This script drops the electronic journal                     #
# tables on the iSeries platform.                              #
#                                                              #
################################################################


java com.ibm.dse.samples.ej.server.RemoveEJTable createElectronicJournalTables.txt
