################################################################
#                                                              #
# File: initializeAgentAdminTables.sh                          #
#                                                              #
# This script purges all tables for the                        #
# Agent Admin e-Component on the iSeries platform.             #
#                                                              #
# NOTE:  You need to have the following jars in the classpath  #
#        or the initialization will fail.                      #
#	 dseb.jar					       #
#        dseaccadm.jar					       #	
#	 dseaccsvc.jar					       #
#	 dsejdbtsvc.jar                                        #
#	 dsejdbsi.jar					       #
#	 dsesci.jar				               #
#	 db2_classes.jar (native driver)		       #
#	 jt400.jar (toolkit driver)                            
################################################################

java com.ibm.dse.applsrv.aa.tools.SecurityUtility initialize
