################################################################
#                                                              #
# File: createAgentAdminTables.sh                              #
#                                                              #
# Usage: createAgentAdminTables.sh                             #
#                                                              #
# This script creates a database BTF and all tables for the    #
# Agent Admin e-Component on the iSeries platform.             #
#                                                              #
################################################################


# Create the database (if necessary)
echo "Creating database BTF for Agent Admin"
db2 "CREATE DATABASE BTF"

# Connect to the security database
# CONNECT TO BTF

echo "Creating tables and indexes for Agent Admin"

echo "Creating table:  users"
# Create the user table
db2 "CREATE TABLE BTF.USERS (USERID CHAR(25) NOT NULL,XID CHAR(10) NOT NULL,PASSWORD CHAR(120),RIGHTS VARCHAR(700),ROLES VARCHAR(700),RIGHT_TIMES VARCHAR(700),ROLE_TIMES VARCHAR(700),ACTIVATION CHAR(20),DURATION CHAR(20),C_LOCK CHAR,TIMELOCK CHAR,DATA VARCHAR(700))"

db2 "CREATE UNIQUE INDEX BTF.INDEXUS ON BTF.USERS (USERID ASC , XID ASC )"

# Create the rights table
echo "Creating table:  rights"
db2 "CREATE TABLE BTF.RIGHTS (RIGHT_NAME CHAR(50) NOT NULL,XID CHAR(10) NOT NULL,DATA VARCHAR(700))"

db2 "CREATE UNIQUE INDEX BTF.INDEXRI ON BTF.RIGHTS (RIGHT_NAME ASC , XID ASC )"

# Create the roles table
echo "Creating table:  roles"
db2 "CREATE TABLE BTF.ROLES (ROLE CHAR(50) NOT NULL,XID CHAR(10) NOT NULL,HANDLER CHAR(100),RIGHTS VARCHAR(700),ROLES VARCHAR(700),DATA VARCHAR(700))"

db2 "CREATE UNIQUE INDEX BTF.INDEXRL ON BTF.ROLES (ROLE ASC , XID ASC )"

# Create the services table
echo "Creating table:  services"
db2 "CREATE TABLE BTF.SERVICES (SERVICE CHAR(50) NOT NULL,XID CHAR(10) NOT NULL,RIGHTS VARCHAR(700),DATA VARCHAR(700))"

db2 "CREATE UNIQUE INDEX BTF.INDEXSV ON BTF.SERVICES (SERVICE ASC , XID ASC )"

# Create the groups table
echo "Creating table:  groups"
db2 "CREATE TABLE BTF.GROUPS (GROUP CHAR(50) NOT NULL,XID CHAR(10) NOT NULL,USERS VARCHAR(700),GROUPS VARCHAR(700),DATA VARCHAR(700))"

db2 "CREATE UNIQUE INDEX BTF.INDEXGR ON BTF.GROUPS (GROUP ASC , XID ASC )"

# Create the contexts table
echo "Creating table:  contexts"
db2 "CREATE TABLE BTF.CONTEXTS (CONTEXT CHAR(12) NOT NULL,XID CHAR(10) NOT NULL,USERID CHAR(10),OVERRIDE CHAR(10),ACTIVE CHAR,FORCEDSIGNOFF CHAR,DATA VARCHAR(700))"

db2 "CREATE UNIQUE INDEX BTF.INDEXCX ON BTF.CONTEXTS (CONTEXT ASC , XID ASC )"

# Create the configuration table
echo "Creating table:  configuration"
db2 "CREATE TABLE BTF.CONFIGURATION (XID CHAR(10) NOT NULL,USRP CHAR,CTXP CHAR,RGTP CHAR,ROLP CHAR,SRVP CHAR,GRPP CHAR,CFGP CHAR,C_AUDIT CHAR,QPASSWORD CHAR,C_UNIQUE CHAR,ROLES VARCHAR(700))"

db2 "CREATE UNIQUE INDEX BTF.INDEXCON ON BTF.CONFIGURATION (XID ASC )"

# Assign the primary keys
db2 "ALTER TABLE BTF.USERS         ADD PRIMARY KEY (USERID  , XID)"
db2 "ALTER TABLE BTF.RIGHTS        ADD PRIMARY KEY (RIGHT_NAME   , XID)"
db2 "ALTER TABLE BTF.ROLES         ADD PRIMARY KEY (ROLE    , XID)"
db2 "ALTER TABLE BTF.SERVICES      ADD PRIMARY KEY (SERVICE , XID)"
db2 "ALTER TABLE BTF.GROUPS        ADD PRIMARY KEY (GROUP   , XID)"
db2 "ALTER TABLE BTF.CONTEXTS      ADD PRIMARY KEY (CONTEXT , XID)"
db2 "ALTER TABLE BTF.CONFIGURATION ADD PRIMARY KEY (XID)"
