################################################################
#                                                              #
# File: purgeAgentAdminTables.sh                               #
#                                                              #
# Usage: purgeAgentAdminTables.sh userid password              #
#                                                              #
# This script purges all tables for the                        #
# Agent Admin e-Component on the iSeries platform.             #
#                                                              #
################################################################

#CONNECT TO BTF 

# Delete tables from database BTF
echo "Purging tables from BTF"
db2 "DELETE FROM BTF.USERS"
db2 "DELETE FROM BTF.RIGHTS"
db2 "DELETE FROM BTF.ROLES"
db2 "DELETE FROM BTF.SERVICES"
db2 "DELETE FROM BTF.GROUPS"
db2 "DELETE FROM BTF.CONTEXTS"
db2 "DELETE FROM BTF.CONFIGURATION"
echo "Tables purged from BTF"
db2 "TERMINATE"
