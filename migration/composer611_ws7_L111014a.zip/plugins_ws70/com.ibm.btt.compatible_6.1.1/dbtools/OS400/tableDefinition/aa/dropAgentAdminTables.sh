################################################################
#                                                              #
# File: dropAgentAdminTables.sh                                #
#                                                              #
# Usage: dropAgentAdminTables.sh                               #
#                                                              #
# This script drops all tables for the                         #
# Agent Admin e-Component on the iSeries platform.             #
#                                                              #
################################################################


#CONNECT TO BTF
echo "Dropping tables from database BTF"
db2 "DROP TABLE BTF.USERS"
db2 "DROP TABLE BTF.CONTEXTS"
db2 "DROP TABLE BTF.RIGHTS"
db2 "DROP TABLE BTF.ROLES"
db2 "DROP TABLE BTF.SERVICES"
db2 "DROP TABLE BTF.GROUPS"
db2 "DROP TABLE BTF.CONFIGURATION"
echo "Tables dropped from database BTF"
#CONNECT RESET
db2 "TERMINATE"
