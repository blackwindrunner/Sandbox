if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CONFIGURATION]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[CONFIGURATION]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CONTEXTS]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[CONTEXTS]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GROUPS]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GROUPS]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RIGHTS]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RIGHTS]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ROLES]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ROLES]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SERVICES]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SERVICES]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[USERS]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[USERS]
GO

CREATE TABLE [dbo].[CONFIGURATION] (
	[XID] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[USRP] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[CTXP] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[RGTP] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ROLP] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[SRVP] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[GRPP] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[CFGP] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[C_AUDIT] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[QPASSWORD] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[C_UNIQUE] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ROLES] [varchar] (700) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[CONTEXTS] (
	[CONTEXT] [char] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[XID] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[USERID] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[OVERRIDE] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ACTIVE] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[FORCEDSIGNOFF] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DATA] [varchar] (700) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[GROUPS] (
	[GROUP] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[XID] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[USERS] [varchar] (700) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[GROUPS] [varchar] (700) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DATA] [varchar] (700) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[RIGHTS] (
	[RIGHT_NAME] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[XID] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DATA] [varchar] (700) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ROLES] (
	[ROLE] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[XID] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[HANDLER] [char] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[RIGHTS] [varchar] (700) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ROLES] [varchar] (700) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DATA] [varchar] (700) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[SERVICES] (
	[SERVICE] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[XID] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[RIGHTS] [varchar] (700) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DATA] [varchar] (700) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[USERS] (
	[USERID] [char] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[XID] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[PASSWORD] [char] (120) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[RIGHTS] [varchar] (700) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ROLES] [varchar] (700) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[RIGHT_TIMES] [varchar] (700) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ROLE_TIMES] [varchar] (700) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ACTIVATION] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DURATION] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[C_LOCK] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[TIMELOCK] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DATA] [varchar] (700) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[CONFIGURATION] WITH NOCHECK ADD 
	CONSTRAINT [PK_CONFIGURATION] PRIMARY KEY  CLUSTERED 
	(
		[XID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[CONTEXTS] WITH NOCHECK ADD 
	CONSTRAINT [PK_CONTEXTS] PRIMARY KEY  CLUSTERED 
	(
		[CONTEXT],
		[XID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[GROUPS] WITH NOCHECK ADD 
	CONSTRAINT [PK_GROUPS] PRIMARY KEY  CLUSTERED 
	(
		[GROUP],
		[XID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[RIGHTS] WITH NOCHECK ADD 
	CONSTRAINT [PK_RIGHTS] PRIMARY KEY  CLUSTERED 
	(
		[RIGHT_NAME],
		[XID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ROLES] WITH NOCHECK ADD 
	CONSTRAINT [PK_ROLES] PRIMARY KEY  CLUSTERED 
	(
		[ROLE],
		[XID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[SERVICES] WITH NOCHECK ADD 
	CONSTRAINT [PK_SERVICES] PRIMARY KEY  CLUSTERED 
	(
		[SERVICE],
		[XID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[USERS] WITH NOCHECK ADD 
	CONSTRAINT [PK_USERS] PRIMARY KEY  CLUSTERED 
	(
		[USERID],
		[XID]
	)  ON [PRIMARY] 
GO
