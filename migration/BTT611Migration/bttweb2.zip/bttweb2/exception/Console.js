/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
var ifDebug=Config.debugMode;function Console(){this.console=null;this.init();};Console.prototype={init:function(){try{loadFirebugConsole();}catch(e){}this.console=window.console;var _1=["log","debug","info","warn","error","assert","dir","dirxml","group","groupEnd","time","timeEnd","count","trace","profile","profileEnd"];for(var i=0;i<_1.length;++i){var _3=_1[i];if(ifDebug&&this.console!=null){this[_3]=this._proxy(_3,this.console);}else{this[_3]=this._$proxy(_3);}}},_proxy:function(_4,_5){return function(){try{_5[_4].apply({},arguments);}catch(e){try{if(typeof (arguments[0])=="string"){_5["log"].apply({},arguments);}else{_5["dir"].apply({},arguments);}}catch(e){try{var _6="";for(var i=0;i<arguments.length;i++){var _8=arguments[i];_6+=_8.getStackTrace?_8.getStackTrace():_8.toString();}console[_4](_6);}catch(e){throw _6;}}}};},_$proxy:function(_9){return function(){if(_9="error"){}else{}};}};var BTTConsole=new Console();
