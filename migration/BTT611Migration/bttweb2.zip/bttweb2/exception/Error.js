/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
if(Config.debugMode==true){window.onerror=function(_1,_2,_3){};}function BTTError(e,m){this.error=e||new Error();this.message=m||"";this.type="BTTError";};BTTError.prototype={toString:function(){return this.type+":"+this.getMessage();},getMessage:function(){return this.message+":"+this.error.message;},getType:function(){return this.type;},getStackTrace:function(){if(this.error.fileName){return "BTTErrorStack:\n"+" Type:"+this.type+" \nThe file of "+this.error.fileName+" has error\nLine:"+this.error.lineNumber+"\nMessage:"+this.getMessage();}else{return "BTTErrorStack:\n"+" Type:"+this.type+" \nMessage:"+this.getMessage();}}};function BTTSynaxError(e,m){this.error=e||new Error();this.message=m||"";this.type="BTTSyntaxError";};BTTSynaxError.extend(BTTError,{getType:function(){return this.type+": "+this.error.name;}});function BTTNullError(e,m){this.error=e||new Error();this.message=m||"The object is null";this.type="BTTNullError";};BTTNullError.extend(BTTError);function BTTXmlError(e,m){this.error=e||new Error();this.message=m||"The xml file has error";this.type="BTTXmlError";};BTTXmlError.extend(BTTError);function BTTTypeError(e,m){this.error=e||new Error();this.message=m||"The object type has error";this.type="BTTTypeError";};BTTTypeError.extend(BTTError);function BTTWidgetError(e,m){this.error=e||new Error();this.message=m||"The widget has error";this.type="BTTWidgetError";};BTTWidgetError.extend(BTTError);
