/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
var BTTColumnContainerComp=BTTUtil.extend(BTTContainer,{baseCls:"btt_rows_baseCls",initComponent:function(){BTTColumnContainerComp.superclass.initComponent.call(this);var d=this.el;d.innerHTML=BTTColumnContainerComp.boxMarkup;this.body=d.firstChild;this.initItems();this.initEvents();if(!this.itemTpl){var tt=new BTTTemplate("<div id={id} class=\"btt_row\"></div>");tt.compile();BTTColumnContainerComp.prototype.itemTpl=tt;}},onRender:function(ct,_4){BTTColumnContainerComp.superclass.onRender.call(this,ct,_4);ct.insertBefore(this.el,_4);this.items.each(this.initRow,this);},initEvents:function(){this.addListener("add",this.onAdd,this);this.addListener("remove",this.onRemove,this);},onBodyMouseDown:function(e){if(!e){e=window.event;}},initRow:function(_6,_7){var _8=this.body.childNodes[_7];var p={id:_6.id};var el=_8?this.itemTpl.insertBefore(_8,p):this.itemTpl.append(this.body,p);el.tabIndex=0;var o={id:_6.id,title:_6.title,basicDM:this.basicDM.ItemArray.get(_6.id),renderTo:el,render:false};var _c=new BTTWidgetVO(o);this.items.replace(_6.id,_c);},onAdd:function(_d,_e){this.initRow(_d,_e);},getRowEl:function(_f){var _10;if(typeof _f=="object"){_10=_f.id;}else{_10=_f;}return document.getElementById(_10);},getItem:function(_11){return this.getComponent(_11);},findTargets:function(e){}});BTTColumnContainerComp.boxMarkup="<div class=\"btt_rows_container\"></div>";
