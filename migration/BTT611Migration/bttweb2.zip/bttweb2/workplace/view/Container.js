/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
var BTTContainer=function(){};BTTContainer=BTTUtil.extend(BTTComponent,{initComponent:function(){BTTContainer.superclass.initComponent.call(this);this.addEvents("add","remove");var _1=this.items;if(_1){if(BTTUtil.isArray(_1)){this.add.apply(this,_1);}else{this.add(_1);}}},initItems:function(){if(!this.items){this.items=new BTTComponentArray();}},render:function(){},add:function(_2){if(!this.items){this.initItems();}var a=arguments,_4=a.length;if(_4>1){for(var i=0;i<_4;i++){this.add(a[i]);}return;}var c=this.applyDefaults(_2);var _7=this.items.length;this.items.add(c);c.ownerCt=this;this.fireEvent("add",c,_7);return c;},insert:function(_8,_9){if(!this.items){this.initItems();}var a=arguments,_b=a.length;if(_b>2){for(var i=_b-1;i>=1;--i){this.insert(_8,a[i]);}return;}var c=this.applyDefaults(_9);if(c.ownerCt==this&&this.items.indexOf(c)<_8){--_8;}this.items.insert(_8,c);c.ownerCt=this;return c;},applyDefaults:function(c){if(this.defaults){if(typeof c=="string"){c=BTTComponentMgr.get(c);BTTUtil.apply(c,this.defaults);}else{BTTUtil.apply(c,this.defaults);}}return c;},remove:function(_f){var c=this.getComponent(_f);this.items.remove(c);this.fireEvent("remove",c);return c;},getComponent:function(_11){if(typeof _11=="object"){return _11;}return this.items.get(_11);}});
