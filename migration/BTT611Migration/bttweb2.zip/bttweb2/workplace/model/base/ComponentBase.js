/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
function BTTComponentBase(){};BTTComponentBase.prototype={id:undefined,getId:function(){return this.id;},setId:function(id){this.id=id;},getAttribute:function(_2){return this[_2];},setAttribute:function(_3,_4){this[_3]=_4;}};
