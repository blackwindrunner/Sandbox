/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
function BTTColumn(){};BTTColumn.prototype={basic:null,minWidth:null,maxWidth:null,draggable:null,closable:null,width:null,getWidth:function(){return this.width;},setWidth:function(_1){this.width=_1;},isBasic:function(){return this.basic;},setBasic:function(_2){this.basic=_2;},getDraggable:function(){return this.draggable;},setDraggable:function(_3){this.draggable=_3;},getClosable:function(){return this.closable;},setClosable:function(_4){this.closable=_4;},getMaxWidth:function(){return this.maxWidth;},setMaxWidth:function(_5){this.maxWidth=_5;},getMinWidth:function(){return this.minWidth;},setMinWidth:function(_6){this.minWidth=_6;}};BTTColumn.extend(BTTComponentBase);
