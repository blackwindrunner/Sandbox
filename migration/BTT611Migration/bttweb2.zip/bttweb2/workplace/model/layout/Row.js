/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
function BTTRow(){};BTTRow.prototype={title:null,basic:null,draggable:null,getTitle:function(){return this.title;},setTitle:function(_1){this.title=_1;},isBasic:function(){return this.basic;},setBasic:function(_2){this.basic=_2;},getDraggable:function(){return this.draggable;},setDraggable:function(_3){this.draggable=_3;}};BTTRow.extend(BTTComponentBase);
