/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
function BTTPage(){};BTTPage.prototype={basic:null,maxColLength:null,isBasic:function(){return this.basic;},setBasic:function(_1){this.basic=_1;},getMaxColLength:function(){return this.maxColLength;},setMaxColLength:function(_2){this.maxColLength=_2;}};
