/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
function BTTTab(){};BTTTab.prototype={logo:null,maxColLength:null,title:null,editable:null,closable:null,basic:null,getLogo:function(){return this._logo;},setLogo:function(_1){this.logo=_1;},getMaxColLength:function(){return this.maxColLength;},setMaxColLength:function(_2){this.maxColLength=_2;},getTitle:function(){return this.title;},setTitle:function(_3){this.title=BTTLocale.getText(_3);},isBasic:function(){return this.basic;},setBasic:function(_4){this.basic=_4;},getClosable:function(){return this.closable;},setClosable:function(_5){this.closable=_5;},getEditable:function(){return this.editable;},setEditable:function(_6){this.editable=_6;}};BTTTab.extend(BTTComponentBase);
