/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
function BTTServiceBase(){};BTTServiceBase.prototype={name:undefined,logo:undefined,desc:undefined,expand:undefined,getName:function(){return this.name;},setName:function(_1){this.name=_1;},getLogo:function(){return this.logo;},setLogo:function(_2){this.logo=_2;},getDesc:function(){return this.desc;},setDesc:function(_3){this.desc=_3;},getExpand:function(){return this.expand;},setExpand:function(_4){this.expand=_4;}};BTTServiceBase.extend(BTTComponentBase);
