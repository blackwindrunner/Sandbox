/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
function BTTServiceRepository(){};BTTServiceRepository.prototype={extend:null,getExtend:function(){return this.extend;},setExtend:function(_1){this.extend=_1;}};BTTServiceRepository.extend(BTTServiceBase);
