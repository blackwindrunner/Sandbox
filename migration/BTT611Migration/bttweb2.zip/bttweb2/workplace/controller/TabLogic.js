/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
function BTTTabVO(_1){this.superClass(_1);};BTTTabVO.prototype={initContainer:function(_2){if(!_2){return false;}var id=this.id;if(!id){return false;}var _4=_2.getItemEl(id).tabcontentel;var o={renderTo:_4,render:true,basicDM:this};return this.container=new BTTTabPanelVO(o);},initItem:function(_6){var _7=new BTTColumnVO({parentVO:this,id:_6.getAttribute("id")});return _7;},addColumn:function(_8){var _9=false;if(!_8){_9=true;_8=this._addColumn();}if(_8==false){return false;}var _a=new BTTItemColumnWrap(_8);if(!this.container){this.container=this.initContainer(this._getParentVO());}this.container.add(_a);var _b=this._getItemVOById(_8.getId());_b.container=_b.initContainer(this);if(_9==true){this.resetAllItemColumnWidth();}},resetAllItemColumnWidth:function(){var _c=this.ItemArray.getCount();var _d=(Math.ceil((95)/_c))+"%";for(var i=0;i<_c;i++){var _f=this.ItemArray.get(i);_f._setColumnWidth(_d);_f.getDomEl().style.width=_d;}},closeColumn:function(id){if(this._closeColumn(id)==false){return false;}},startEditTabTitle:function(){if(this._isEditableTab()==false){return false;}},startEditTabLogo:function(){if(this._isEditableTab()==false){return false;}},editTabTitle:function(_11){this._editTabTitle(_11);},editTabLogo:function(_12){this._editTabLogo(_12);},getItemEl:function(id){return this.container.getColumnEl(id);}};BTTTabVO.extend(BTTAbstractTabLogic);var BTTItemColumnWrap=function(_14){this.id=_14.getAttribute("id");this.width=_14.getAttribute("width");};
