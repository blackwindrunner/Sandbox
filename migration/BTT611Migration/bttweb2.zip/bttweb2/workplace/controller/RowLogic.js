/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
function BTTRowVO(_1){this.superClass(_1);};BTTRowVO.prototype={editRow:function(_2){this._edit(_2);},toggleRow:function(){this._toggle();},refreshRow:function(){this._refresh();},restoreRow:function(){this._restore();},maxRow:function(){this._max();}};BTTRowVO.extend(BTTAbstractRowLogic);
