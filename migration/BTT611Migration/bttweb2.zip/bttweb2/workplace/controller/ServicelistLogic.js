/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
function BTTServicelistLogicVO(_1){this.superClass(_1);};BTTServicelistLogicVO.prototype={initContainer:function(){this._initServiceList();var _2=this.rootlogic.getServiceJson();var _3=new BTTServiceCategoryNode({children:_2,expand:"1"});var _4=document.getElementById(BTTMain.BTTConfig.NAVID);var o={renderTo:_4,root:_3,render:true,basicDM:this};var _6=new BTTServicePanel(o);this.container=_6;},initItem:function(_7){var _8={id:_7.getId()};var _9=new BTTServiceNodeLogic(_8);return _9;}};BTTServicelistLogicVO.extend(BTTAbstractServiceLogic);function BTTServiceNodeLogic(_a){this.superClass(_a);};BTTServiceNodeLogic.prototype={getServiceName:function(){return this._getModel().getName();},getServiceJsonStr:function(){var a=[];var _c;var ts="\"id\":\""+this._getModel().getId()+"\"";a.push(ts);var ts="\"name\":\""+this.getServiceName()+"\"";a.push(ts);ts="\"logo\":\""+this._getServiceLogo()+"\"";a.push(ts);ts="\"desc\":\""+this._getServiceDesc()+"\"";a.push(ts);ts="\"expand\":\""+this._getServiceExpand()+"\"";a.push(ts);_c=a.join(",");if(this._isServiceLeaf()==true){return "{"+_c+",\"leaf\":true"+"}";}else{_c=_c+",\"leaf\":false";var _e=[];var _f=this._getItemNodes();for(var j=0;j<_f.length;j++){var _11=_f.itemAt(j);var _12=_11.getServiceJsonStr();_e.push(_12);}var _13=_e.join(",");_c="{"+_c+",\"children\":["+_13+"]}";return ""+_c+"";}},getServiceJson:function(){var str=this.getServiceJsonStr();return eval("["+str+"]");}};BTTServiceNodeLogic.extend(BTTAbstractServiceNodeLogic);
