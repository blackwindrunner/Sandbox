/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
function BTTPageVO(){this.ItemArray=new BTTComponentArray();};BTTPageVO.prototype={activeItemId:-1,initItem:function(_1){var _2=new BTTTabVO({parentVO:this,id:_1.getId()});return _2;},initContainer:function(){var _3=document.getElementById(BTTMain.BTTConfig.TABID);var _4=document.getElementById(BTTMain.BTTConfig.CONTAINERID);var o={renderTo:_3,contentbody:_4,render:true,basicDM:this};return this.container=new BTTTabContainerPanelVO(o);},addTab:function(_6){if(!_6){_6=this._addTab();}var _7=new BTTItemPageWrap(_6);var _8=new BTTTabVO(_7);this.container.add(_8);this.container.setActiveTab(_8);},afterInitContainer:function(){this.container.setActiveTab(0);},closeTab:function(id){if(this._closeTab(id)==false){return false;}},getItemEl:function(id){return this.container.getTabEl(id);}};BTTPageVO.extend(BTTAbstractPageLogic);var BTTItemPageWrap=function(_b){this.id=_b.getAttribute("id");this.logo=_b.getAttribute("logo");this.title=_b.getAttribute("title");};
