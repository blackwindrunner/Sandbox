/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
function BTTLayoutRepository(_1){this.factory=_1;this.repository=new BTTComponentArray();};BTTLayoutRepository.extend(BTTRepository,{getBasicPage:function(){return this.getItem(function(_2){return (_2.key=="Page"&&_2.isBasic()==true);});},getUserPage:function(){return this.getItem(function(_3){return (_3.key=="Page"&&_3.isBasic()!=true);});}});var BTTLayoutComponent=new BTTLayoutRepository(BTTComponentFactory);var BTTLayoutEngine=new BTTIocEngine(BTTLayoutComponent,"PageFormatter");
