/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
var BTTIocEngine=function(_1,_2,_3){this.repository=_1;this.rootTag=_2;this.namespace=_3;};BTTIocEngine.prototype={parse:function(_4){var _5=XMLUtil.parse(_4);parse(_5.documentElement,this.repository);function parse(_6,_7){var _8=_7.parse(_6);if(_6.hasChildNodes()){var _9=_6.childNodes;for(var i=0;i<_9.length;i++){var _b=arguments.callee(_9[i],_7);if(_b){if(_b.id==undefined){_b.id=_b.key+"_"+_7.repository.items.length;}if(_8){_b.container=_8;_8.items.push(_b);}_7.repository.add(_b.id,_b);}}}return _8;};},restore:function(){var _c=this.repository.getUserPage();if(_c==null){return;}var _d=XMLUtil.newXMLFile(this.rootTag,this.namespace);_d.documentElement.appendChild(execute(_c));return XMLUtil.serialize(_d);function execute(_e){var _f=_d.createElement(_e.key);for(var p in _e){var _11=p.substr(0,1).toUpperCase()+p.substr(1);var _1=typeof (_e[p])=="string";var _2=typeof (_e["get"+_11])=="function";var _3=typeof (_e["set"+_11])=="function";if(_1&&_2&&_3){_f.setAttribute(p,_e[p]);}}for(var i=0,len=_e.items.length;i<len;i++){var _17=arguments.callee(_e.items[i]);_f.appendChild(_17);}return _f;};}};
