/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
var BTTComponentFactory=new BTTFactory();var BTTRepository=function(_1){this.factory=_1;this.repository=new BTTComponentArray();};BTTRepository.prototype={parse:function(_2){var _3=this.factory.getComponent(_2.nodeName);if(_3==null){return;}var _4=_2.attributes;for(var i=0;i<_4.length;i++){var _6=_4[i].nodeName;var _7="set"+_6.substr(0,1).toUpperCase()+_6.substr(1);if(typeof (_3[_7])=="function"){_3[_7](_4[i].nodeValue);}}_3.items=[];return _3;},getItem:function(_8){var _9=this.repository.items;var _a=null;for(var i=0;i<_9.length;i++){if(_8(_9[i])==true){_a=_9[i];break;}}return _a;}};
