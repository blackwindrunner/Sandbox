/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
var BTTConfigParser=function(_1){this.factory=_1;};BTTConfigParser.prototype={parse:function(_2){var _3=XMLUtil.parse(_2);var _4=_3.documentElement;var _5=_4.getElementsByTagName("component");for(var i=0;i<_5.length;i++){var _7=_5[i].getAttribute("name");var _8=_5[i].getAttribute("class");if(!_7||!_8){continue;}var _9=_5[i].getAttribute("scope")||"window";var fn=window[_9][_8];if(typeof (fn)=="function"){var ex=_5[i].getAttribute("extend");var _c=this.factory.getConstructor(ex);if(_c!=null){fn.extend(_c);}this.factory.register(_7,fn);}else{BTTConsole.error(new BTTXmlError(null,"Cannot find the sepecified constructor accroding to component xml"));}}}};
