/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
var BTTFactory=function(){this.factory={};this._factory={};this.register=function(_1,_2){if(typeof (_2)=="function"&&typeof (_1)=="string"){if(!this.factory[_1]&&!this._factory[_2]){this.factory[_1]=_2;this._factory[_2]=_1;}else{BTTConsole.error(new BTTError(null,"The key has be repeated"));}}else{BTTConsole.error(new BTTError(null,"the constructor must be a function and tagName must be string"));}};this.getComponent=function(_3){var _4=new Array();for(var i=1;i<arguments.length;i++){_4.push(arguments[i]);}var fn=this.factory[_3];if(fn&&typeof (fn)=="function"){var _7=new fn();fn.apply(_7,_4);_7.key=_3;return _7;}return null;};this.getKey=function(_8){return this._factory[_8];};this.getConstructor=function(_9){return this.factory[_9];};this.unRegister=function(_a){delete this.factory[_a];delete this._factory[_a.constructor];};};
