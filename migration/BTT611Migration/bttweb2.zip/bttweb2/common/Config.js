/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2008, 2008 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
/**
 * @fileoverview this file is about BTTConfig , the groble viable to maintain the information about 
 * BTT Web2.0 On-demand Workplace
 */
/**
 * @class BTTConfig The groble attribute for setting up the BTT Web2.0 On-demand Workplace
 */
var BTTConfig=function(config){
	BTTUtil.apply(this,config)
}
BTTConfig.prototype={
  UserId:"default",	
  /**
   * the Component Server Url Path
   */
  ComponentPath:"/BTTWeb2InternetBankWeb/BTTXMLRequest?file=Component.xml",
  /**
   * the BasicInfrastructure.xml Server Url PATH
   */
  BasicInfrastructurePath:"/BTTWeb2InternetBankWeb/BTTXMLRequest?file=BasicInfrastructure.xml",
  /**
   * the DefaultApp.xml Server Url Path
   */
  DefaultAppPath:"/BTTWeb2InternetBankWeb/BTTXMLRequest?file=DefaultApp.xml",
  /**
   * the UserLayout.xml Server Url Path ,this is depended on the UserId attribute
   */
  UserLayoutPath:"/BTTWeb2InternetBankWeb/SaveLayout?username="+this.UserId,
  /**
   * the UserPortal.xml Server Url Path, this is depended on the UserId attribute
   */
  UserPortalPath:"/BTTWeb2InternetBankWeb/SaveWidget?username="+this.UserId,
  /**
   * the Save Function Servlet ,url path
   */
  SaveUserLayoutPath:"/BTTWeb2InternetBankWeb/SaveLayout", 
  /**
   * the Save Poatal Servlet ,url path
   */
  SaveUserPortalPath:"/BTTWeb2InternetBankWeb/SaveWidget",
  /**
   * the BTTService.xml servlet url path
   */
  ServiceListPath:"/BTTWeb2InternetBankWeb/BTTXMLRequest?file=Service.xml",
  /**
   * the path widget catalog xml file
   */
  WidgetCatalogPath:"BTTXML/WidgetCatalog.xml",
  /**
   * the mandantory id for 3 mandantory page HTML DOM-Element id
   */
  TABID:"bttTab",
  CONTAINERID:"bttContainer",
  NAVID:"bttNav"
}