/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2008, 2008 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
 
/**
 * the base uri of language resource file
 */
BTTLocale.baseUri = "BTTWeb20/locale/language/";
BTTLocale.prefix = "Lang-";
BTTLocale.extension = ".js";

/**
 * the mapping from language string to resource file 
 */
BTTLocale.Lang = {
	"zh-cn": "zh_CN",
	"en-gb": "en_GB",
	"en-us": "en_US",
	"en-ca": "en_CA"
}