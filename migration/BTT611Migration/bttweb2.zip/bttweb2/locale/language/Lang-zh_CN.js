/*
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2008, 2008 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
 
BTTLocale.resource = {
	
	computer:"\u7535\u8111",
	school: "\u5b66\u6821{1}\u548c{2}",
	
	add_tab: "\u589e\u52a0\u6807\u7b7e\u9875",
	add_column: "\u589e\u52a0\u4e00\u5217",
	save_page: "\u4fdd\u5b58",
	login: "\u767b\u5f55",
	sign_out: "\u9000\u51fa",
	welcome_back: "\u6b22\u8fce\u56de\u6765\uff0c",
	select_theme: "\u4e3b\u9898\u9009\u62e9: ",
	theme_blue: "\u7ecf\u5178\u84dd",
	theme_green: "\u8349\u5730\u7eff",
	
	//tab name
	basic_tab:"\u57fa\u672c\u6807\u7b7e\u9875",
	
	//service list
	my_service: "\u6211\u7684\u670d\u52a1",
	basic_service: "\u57fa\u672c\u670d\u52a1",
	btt_service: "BTT \u670d\u52a1",
	basic_widget: "\u57fa\u672c\u63a7\u4ef6",
	html_service: "\u7f51\u9875\u63a7\u4ef6",
	web1_transaction: "Web1.0\u4ea4\u6613",
	Generic_UI: "\u901a\u7528\u7528\u6237\u754c\u9762",
	Westpac_HTML_Demo: "Westpac\u94f6\u884cHTML\u5e94\u7528\u793a\u4f8b",
	transfer: "\u8f6c\u8d26\u670d\u52a1",
	credit_card: "\u4fe1\u7528\u5361\u7533\u8bf7\u670d\u52a1",
	
	web2_transaction: "Web2.0\u4ea4\u6613",
	Personal_Profile: "\u4e2a\u4eba\u8d44\u6599\u6863\u6848",
	Currency_Exchange: "\u8d27\u5e01\u5151\u6362\u670d\u52a1",
	account_transfer: "\u5e10\u6237\u8f6c\u8d26",
	Car_Account: "\u8f66\u8d37\u5e10\u6237",
	
	Cars: "\u6c7d\u8f66\u670d\u52a1",
	Car_lend: "\u65b0\u8f66\u52a8\u6001",
	Car_buy: "\u865a\u62df\u8d2d\u8f66",
	Car_detail: "\u6c7d\u8f66\u8be6\u7ec6\u53c2\u6570",
	Car_calculate: "\u8f66\u8d37\u8ba1\u7b97",
	
	Stock: "\u80a1\u7968\u4fe1\u606f",
	Today_Trust: "\u4eca\u65e5\u8d22\u7ecf",
	Yahoo_Stock: "\u96c5\u864e\u80a1\u8bc4",
	
	Finace_Analysis: "\u8d22\u52a1\u5206\u6790\u670d\u52a1",
	Finacing_Analysis_Guide: "\u8d22\u52a1\u5206\u6790\u6307\u5357",
	Income_Allocate_Chart: "\u6536\u5165\u5206\u914d\u56fe",
	Income_Table: "\u6536\u5165\u8868",
	
	My_Tools: "\u6211\u7684\u5de5\u5177",
	Google_Calendar: "\u8c37\u6b4c\u65e5\u5386",
	Flash_Game: "Flash\u6e38\u620f",
	Google_Map: "\u8c37\u6b4c\u5730\u56fe",
	
	E_Business: "\u7535\u5b50\u5546\u52a1",
	
	Financing_Plan: "\u8d22\u52a1\u8ba1\u5212",
	
	Fund_Transaction: "\u57fa\u91d1\u4ea4\u6613",
	
	Fund_Inquiry: "\u57fa\u91d1\u67e5\u8be2",
	
	Fund_Account: "\u57fa\u91d1\u8d26\u6237",
	
	National_Bond: "\u56fd\u503a",
	
	Loan_Management: "\u8d37\u6b3e\u7ba1\u7406",
	
	
		
	//tip
	tip_tab_close:"\u70b9\u51fb\u5173\u95ed\u6807\u7b7e\u9875",
	tip_tab_logo: "\u70b9\u51fb\u7f16\u8f91\u6807\u7b7e\u56fe\u6807",
	tip_max:"\u6700\u5927\u5316",
	tip_restore: "\u8fd8\u539f",
	tip_edit: "\u7f16\u8f91",
	tip_refresh: "\u5237\u65b0",
	tip_collapse: "\u6536\u7f29",
	tip_close: "\u5173\u95ed",
	tip_help: "\u5e2e\u52a9"
	

};