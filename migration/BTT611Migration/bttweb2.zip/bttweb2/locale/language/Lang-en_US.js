/*
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2008, 2008 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
 
BTTLocale.resource = {
	computer:"computer",
	school: "compus",
	
	add_tab: "add new tab",
	add_column: "add new column",
	save_page: "save page",
	login: "login in ",
	sign_out: "Sign Out",
	welcome_back: "Welcome back",
	select_theme: "Theme Select: ",
	theme_blue: "Classic Blue",
	theme_green: "Grass Green",
	
	//tab name
	basic_tab:"Basic Tab",
	
	//service list
	my_service: "My service",
	basic_service:"Basic Service",
	basic_widget: "Basic Widgets",
	btt_service: "BTT Service",
	html_service: "Html Service",
	web1_transaction: "Web1.0 Transaction",
	
	Generic_UI: "Generic UI",
	Westpac_HTML_Demo: "Westpac HTML Demo",
	transfer: "Transfer",
	credit_card: "Credit Card",
	
	web2_transaction: "Web2 Transaction",
	Personal_Profile: "Personal Profile",
	Currency_Exchange: "Currency Exchange",
	account_transfer: "Account Transfer",
	Car_Account: "Car Account",
	
	Cars: "Cars",
	Car_lend: "Car lend",
	Car_buy: "Car buy",
	Car_detail: "Car Detail",
	Car_calculate: "Car Calculate",
	
	Stock: "Stock",
	Today_Trust: "Today Trust",
	Yahoo_Stock: "Yahoo Stock",
	
	Finace_Analysis: "Finace Analysis",
	Finacing_Analysis_Guide: "Finacing Analysis Guide",
	Income_Allocate_Chart: "Income Allocate Chart",
	Income_Table: "Income Table",
	
	My_Tools: "My Tools",
	Google_Calendar: "Google Calendar",
	Flash_Game: "Flash Game",
	Google_Map: "Google Map",
	
	E_Business: "E Business",
	
	Financing_Plan: "Financing Plan",
	
	Fund_Transaction: "Fund Transaction",
	
	Fund_Inquiry: "Fund Inquiry",
	
	Fund_Account: "Fund Account",
	
	National_Bond: "National Bond",
	
	Loan_Management: "Loan Management",
	
	//tip
	tip_tab_close:"click to close tab",
	tip_tab_logo: "click to edit tab logo",
	tip_max:"max",
	tip_restore: "restore",
	tip_edit: "edit",
	tip_refresh: "refresh",
	tip_collapse: "collapse",
	tip_close: "close",
	tip_help: "help"
	
//Attention: Don't add "," after last key-value couple	
}