/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
var BTTLocale=new Object();BTTLocale={getOSLang:function(){return (window.navigator.language||navigator.userLanguage).toString().toLowerCase();},getLang:function(){return BTTLocale.Lang[BTTLocale.getOSLang()];},getLocaleUri:function(){return BTTLocale.baseUri+BTTLocale.prefix+BTTLocale.getLang()+BTTLocale.extension;},getText:function(_1){if(_1==null){BTTConsole.error(new BTTTypeError(null,"BTTLocale.getText() parameter cannot be null"));}if(BTTLocale.resource){var _2=BTTLocale.resource[_1]||_1;if(arguments.length>=1){for(var i=1;i<arguments.length;i++){var re=new RegExp("{["+i+"]}","g");_2=_2.replace(re,arguments[i]);}}return _2;}},getLangResource:function(_5,_6){var _7=BTTLocale.getLocaleUri();if(_7!=null){var _8=[];for(var i=2;i<arguments.length;i++){_8.push(arguments[i]);}function loadLang(_a){try{window.eval(_a.responseText);}catch(e){BTTConsole.error(new BTTError(e,"The language resource js has syntax error"));}if(_5){_5.apply(_6,_8);}};Request.send(_7,"GET",loadLang);}else{throw BTTError(null,"Can't find corresponding language resource file");}}};
