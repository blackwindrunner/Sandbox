/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
function Widget(){this.wgtDef=null;this.iScope=null;this.wgtID=null;this.domDivRoot=null;this.containerId=null;this.setWgtDef=function(_1){this.wgtDef=_1;};this.getwgtDef=function(){return this.wgtDef;};this.getiScope=function(){return this.iScope;};this.setiScope=function(_2){this.iScope=_2;};this.getWgtID=function(){return this.wgtID;};this.setWgtID=function(_3){this.wgtID=_3;};this.getContainerId=function(){return this.containerId;};this.setContianerId=function(id){this.containerId=id;};this.addHTMLContent=function(_5){var _6=_5||this.wgtDef.getContents().view;this.domDivRoot.innerHTML=_6;};this.setRootElement=function(_7){var _8=document.createElement("div");_8.setAttribute("icontext_id",this.wgtID);_8.style.height="100%";this.widgetDiv=_8;_7.innerHTML="";_7.appendChild(this.widgetDiv);this.domDivRoot=_8;};this.createIScope=function(){try{this.iScope=new window[this.wgtDef.getIScope()]();}catch(e){var _9=new BTTWidgetError(e,"Cannot find the construtor of specified widget");BTTConsole.error(_9);}};this.addContent=function(_a){var _b=this.wgtDef.getContents()[_a];if(_b!=null){this.domDivRoot.innerHTML=_b;}else{BTTConsole.error(new BTTWidgetError(null,"The specified mode is not defined"));}};this.addDomContent=function(_c){if(_c==null){BTTConsole.error(new BTTTypeError(null,"The addDomContent()'s parameter cannot be null"));}this.domDivRoot.appendChild(_c);};};
