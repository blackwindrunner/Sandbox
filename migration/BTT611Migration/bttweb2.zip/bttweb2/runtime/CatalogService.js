/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
function CatalogService(){this.entries=null;this._parseCatalogFile=function(_1){var _2=_1.getElementsByTagName("entries");if(_2.length==null){return null;}var _3={};var _4=_1.getElementsByTagName("entry");for(var i=0;i<_4.length;i++){if(_4[i].getAttribute("id")==null){continue;}var _6=_4[i].getAttribute("id");if(_3[_6]!=null){BTTConsole.warn("The widget id is duplicate");}_3[_6]={};var _7=_4[i].attributes;for(var j=0;j<_7.length;j++){if(_7[j].nodeName=="id"){continue;}_3[_6][_7[j].nodeName]=_7[j].nodeValue;}var _9=_4[i].childNodes;for(var j=0;j<_9.length;j++){if(_9[j].nodeType==1){_3[_6][_9[j].nodeName]=_9[j].firstChild.nodeValue;}}}return _3;};this.parse=function(_a){try{var _b=XMLUtil.parse(_a);this.entries=this._parseCatalogFile(_b);}catch(e){BTTConsole.error(new BTTError(e,"catalogService initialization failed"));}return this.entries;};this.getWgtDef=function(_c){if(_c==null){BTTConsole.error(new BTTTypeError(null,"The id of widget is null!"));}if(this.entries==null){BTTConsole.error(new BTTXmlError(null,"The entries has no child or the parsing catalog xml has error"));}if(this.entries[_c]==null){var s=this.entries;BTTConsole.error(new BTTXmlError(null,"Cannot find the specified widget in catalog"));}var _e=this.entries[_c].definition;if(_e==null||_e.trim()==""){BTTConsole.error(new BTTXmlError(null,"The entry item is without 'definition' attribute or it is null"));}return _e.trim();};};
