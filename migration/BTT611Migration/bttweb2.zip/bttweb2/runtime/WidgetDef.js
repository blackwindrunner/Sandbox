/**
 * Licensed Materials - Property of IBM
 * Restricted Materials of IBM
 * 5724-H82
 * (C) Copyright IBM Corp. 2009, 2009 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp
 */
function WidgetDef(){this.name=null,this.contents=null,this.iScope=null,this.itemSets=null,this.supportedModes=null,this.mode=null,this.resources=null,this.setName=function(n){this.name=n;};this.getName=function(){return this.name;};this.setContents=function(c){this.contents=c;};this.getContents=function(){return this.contents;};this.getIScope=function(){return this.iScope;};this.setIScope=function(i){this.iScope=i;};this.setItemSets=function(a){this.itemSets=a;};this.getItemSets=function(){return this.itemSets;};this.setSupportedModes=function(s){this.supportedModes=s;};this.getSupportedModes=function(){return this.supportedModes;};this.setMode=function(m){this.mode=m;};this.getMode=function(){return this.mode;};this.setResources=function(r){this.resources=r;};this.getResouces=function(){return this.resources;};this.getContentByMode=function(_8){this.contents[_8];};this.getDefAttributes=function(){return this.itemSets["attributes"];};this.overrideAttribute=function(_9){for(var p in _9){this.itemSets["attributes"].items[p]={id:p,value:_9[p]};}};};
