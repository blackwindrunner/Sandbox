define(
({
		previousMessage: "Предыдущие варианты",
		nextMessage: "Следующие варианты"
})
);
