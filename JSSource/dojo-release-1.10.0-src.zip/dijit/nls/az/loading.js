define(
({
	"loadingState" : "Yüklənir...",
	"errorState" : "Problem yarandı"
})
);
