define(
({
	invalidMessage: "Въведената стойност е невалидна.",
	missingMessage: "Тази стойност се изисква.",
	rangeMessage: "Тази стойност е извън обхват."
})
);
