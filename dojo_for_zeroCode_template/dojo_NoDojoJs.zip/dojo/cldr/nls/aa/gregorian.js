//>>built
define("dojo/cldr/nls/aa/gregorian",{"timeFormat-long":"h:mm:ss a z","timeFormat-medium":"h:mm:ss a","timeFormat-short":"h:mm a","timeFormat-full":"h:mm:ss a zzzz"});