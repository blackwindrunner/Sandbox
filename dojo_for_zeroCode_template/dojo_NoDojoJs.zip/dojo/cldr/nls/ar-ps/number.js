//>>built
define("dojo/cldr/nls/ar-ps/number",{"decimalFormat-long":"0 بليون","decimalFormat-short":"0 بليون"});