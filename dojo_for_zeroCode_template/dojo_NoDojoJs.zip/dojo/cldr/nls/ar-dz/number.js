//>>built
define("dojo/cldr/nls/ar-dz/number",{"group":".","decimal":","});