//>>built
define("dojo/cldr/nls/af-na/currency",{"NAD_symbol":"$"});