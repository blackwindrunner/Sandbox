//>>built
define("dojo/cldr/nls/ar-eg/number",{"nan":"NaN"});