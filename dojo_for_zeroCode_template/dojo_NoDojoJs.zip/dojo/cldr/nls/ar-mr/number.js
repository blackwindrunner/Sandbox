//>>built
define("dojo/cldr/nls/ar-mr/number",{"group":".","decimal":","});