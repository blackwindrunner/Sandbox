//>>built
define("dojo/cldr/nls/ar-ly/number",{"group":".","decimal":","});