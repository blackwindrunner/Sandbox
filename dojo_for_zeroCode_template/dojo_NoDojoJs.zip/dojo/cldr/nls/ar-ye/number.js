//>>built
define("dojo/cldr/nls/ar-ye/number",{"currencyFormat":"¤#0.00"});