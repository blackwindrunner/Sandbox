//>>built
define("dojo/cldr/nls/aa-er/currency",{"ERN_symbol":"Nfk"});