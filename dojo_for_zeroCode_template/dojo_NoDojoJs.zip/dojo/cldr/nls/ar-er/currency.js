//>>built
define("dojo/cldr/nls/ar-er/currency",{"ERN_symbol":"Nfk"});