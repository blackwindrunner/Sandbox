//>>built
define("dojo/cldr/nls/ar-sy/number",{"currencyFormat":"¤#0.00"});