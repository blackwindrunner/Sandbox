//>>built
define("dojo/cldr/nls/ar-ss/currency",{"GBP_symbol":"GB£","SSP_symbol":"£"});