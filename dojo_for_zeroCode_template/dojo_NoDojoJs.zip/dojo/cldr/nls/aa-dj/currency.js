//>>built
define("dojo/cldr/nls/aa-dj/currency",{"DJF_symbol":"Fdj"});