//>>built
define("dojo/cldr/nls/ar-dj/currency",{"DJF_symbol":"Fdj"});