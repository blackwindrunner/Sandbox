//>>built
define("dojo/cldr/nls/ar-tn/number",{"currencyFormat":"¤#0.00","group":".","decimal":","});