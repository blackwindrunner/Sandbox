define(
({
	invalidMessage: "Введено невірне значення.",
	missingMessage: "Це значення є обов'язковим.",
	rangeMessage: "Це значення за межами діапазону."
})
);
