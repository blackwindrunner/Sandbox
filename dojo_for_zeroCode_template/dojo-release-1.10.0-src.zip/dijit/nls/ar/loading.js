define(
({
	loadingState: "جاري التحميل...",
	errorState: "عفوا، حدث خطأ"
})
);
