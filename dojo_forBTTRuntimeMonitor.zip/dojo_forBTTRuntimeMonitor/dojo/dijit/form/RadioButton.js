define("dijit/form/RadioButton", ["dojo", "dijit", "dijit/form/CheckBox"], function(dojo, dijit) {

// TODO: for 2.0, move the RadioButton code into this file


return dijit.form.RadioButton;
});
