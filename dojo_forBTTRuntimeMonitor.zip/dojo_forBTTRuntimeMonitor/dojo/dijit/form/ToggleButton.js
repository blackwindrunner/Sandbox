define("dijit/form/ToggleButton", ["dojo", "dijit", "dijit/form/Button"], function(dojo, dijit) {



return dijit.form.ToggleButton;
});
