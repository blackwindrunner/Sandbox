define(
//begin v1.x content
({
		previousMessage: "Előző menüpontok",
		nextMessage: "További menüpontok"
})
//end v1.x content
);
