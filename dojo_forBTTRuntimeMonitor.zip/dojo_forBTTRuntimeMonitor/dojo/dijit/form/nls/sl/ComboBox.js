define(
//begin v1.x content
({
		previousMessage: "Prejšnje izbire",
		nextMessage: "Dodatne izbire"
})

//end v1.x content
);
