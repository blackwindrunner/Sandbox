define(
//begin v1.x content
({
	invalidMessage: "הערך שצוין אינו חוקי.",
	missingMessage: "זהו ערך דרוש.",
	rangeMessage: "הערך מחוץ לטווח."
})
//end v1.x content
);
