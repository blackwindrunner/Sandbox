define(
//begin v1.x content
({
		previousMessage: "Vorherige Auswahl",
		nextMessage: "Weitere Auswahlmöglichkeiten"
})
//end v1.x content
);
