define(
//begin v1.x content
({
	loadingState: "Probíhá načítání...",
	errorState: "Omlouváme se, došlo k chybě"
})
//end v1.x content
);
