define(
//begin v1.x content
({
	loadingState: "Laster inn...",
	errorState: "Det oppsto en feil"
})
//end v1.x content
);
