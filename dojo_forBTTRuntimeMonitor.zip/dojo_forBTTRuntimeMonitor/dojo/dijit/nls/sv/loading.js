define(
//begin v1.x content
({
	loadingState: "Läser in...",
	errorState: "Det uppstod ett fel."
})
//end v1.x content
);
