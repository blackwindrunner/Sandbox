define(
//begin v1.x content
({
	loadingState: "Загрузка...",
	errorState: "Извините, возникла ошибка"
})
//end v1.x content
);
