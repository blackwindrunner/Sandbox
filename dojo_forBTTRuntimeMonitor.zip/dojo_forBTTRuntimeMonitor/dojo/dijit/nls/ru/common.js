define(
//begin v1.x content
({
	buttonOk: "ОК",
	buttonCancel: "Отмена",
	buttonSave: "Сохранить",
	itemClose: "Закрыть"
})
//end v1.x content
);
