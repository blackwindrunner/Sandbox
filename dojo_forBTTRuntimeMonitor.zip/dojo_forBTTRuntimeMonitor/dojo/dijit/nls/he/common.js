define(
//begin v1.x content
({
	buttonOk: "אישור",
	buttonCancel: "ביטול",
	buttonSave: "שמירה",
	itemClose: "סגירה"
})
//end v1.x content
);
