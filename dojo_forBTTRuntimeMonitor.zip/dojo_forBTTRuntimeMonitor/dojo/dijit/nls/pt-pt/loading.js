define(
//begin v1.x content
({
	loadingState: "A carregar...",
	errorState: "Lamentamos, mas ocorreu um erro"
})
//end v1.x content
);
